const music = document.getElementById("music");
const musicBtn = document.getElementById("musicBtn");
const progressBar = document.getElementById("progressBar");

let currentScreen = 1;
let musicPlaying = false;


// ===============================
// MUSIC
// ===============================

musicBtn.addEventListener("click", async () => {

    try {

        if (musicPlaying) {

            music.pause();

            musicBtn.innerHTML = "🎵 <span>Music</span>";

            musicPlaying = false;

        } else {

            await music.play();

            musicBtn.innerHTML = "🔊 <span>Playing</span>";

            musicPlaying = true;
        }

    } catch (error) {

        alert("Please make sure song.mp3 exists in the same folder.");
    }

});


// ===============================
// SCREEN NAVIGATION
// ===============================

function nextScreen(number) {

    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.remove("active");
    });

    const next = document.getElementById("screen" + number);

    if (next) {
        next.classList.add("active");
    }

    currentScreen = number;

    updateProgress();

    if (number === 2) {
        startTyping();
    }

}


// ===============================
// PROGRESS
// ===============================

function updateProgress() {

    let percentage =
        (currentScreen / 7) * 100;

    progressBar.style.width =
        percentage + "%";
}


// ===============================
// TYPEWRITER
// ===============================

function startTyping() {

    const element =
        document.getElementById("typingText");

    const text =
        "Our friendship is genuinely special to me...";

    element.textContent = "";

    let index = 0;

    function type() {

        if (index < text.length) {

            element.textContent += text.charAt(index);

            index++;

            setTimeout(type, 65);
        }
    }

    type();
}


// ===============================
// THINK BUTTON
// ===============================

function showThink() {

    nextScreen(6);
}


// ===============================
// YES
// ===============================

function sayYes() {

    nextScreen(7);

    launchConfetti();

    createHeartExplosion();

    // Add celebration music volume
    music.volume = 0.8;

}


// ===============================
// CONFETTI
// ===============================

function launchConfetti() {

    const container =
        document.getElementById("confetti");

    const symbols = [
        "💗",
        "✨",
        "💫",
        "🌸",
        "💕",
        "⭐"
    ];

    for (let i = 0; i < 100; i++) {

        const piece =
            document.createElement("div");

        piece.className =
            "confetti-piece";

        piece.innerHTML =
            symbols[
                Math.floor(
                    Math.random() * symbols.length
                )
            ];

        piece.style.left =
            Math.random() * 100 + "vw";

        piece.style.fontSize =
            (10 + Math.random() * 20) + "px";

        piece.style.animationDuration =
            (2.5 + Math.random() * 3) + "s";

        piece.style.animationDelay =
            Math.random() * 1.5 + "s";

        container.appendChild(piece);

        setTimeout(() => {
            piece.remove();
        }, 6000);
    }
}


// ===============================
// HEART EXPLOSION
// ===============================

function createHeartExplosion() {

    const emojis = [
        "💗",
        "💕",
        "💖",
        "✨",
        "🥹"
    ];

    for (let i = 0; i < 35; i++) {

        const heart =
            document.createElement("div");

        heart.innerHTML =
            emojis[
                Math.floor(
                    Math.random() * emojis.length
                )
            ];

        heart.style.position = "fixed";

        heart.style.left = "50%";
        heart.style.top = "50%";

        heart.style.fontSize =
            (15 + Math.random() * 25) + "px";

        heart.style.zIndex = "60";

        heart.style.pointerEvents = "none";

        document.body.appendChild(heart);

        const angle =
            Math.random() * Math.PI * 2;

        const distance =
            100 + Math.random() * 300;

        const x =
            Math.cos(angle) * distance;

        const y =
            Math.sin(angle) * distance;

        heart.animate(
            [
                {
                    transform: "translate(-50%, -50%) scale(0)",
                    opacity: 1
                },
                {
                    transform:
                        `translate(calc(-50% + ${x}px),
                        calc(-50% + ${y}px))
                        scale(1.5)`,
                    opacity: 0
                }
            ],
            {
                duration: 1800,
                easing: "cubic-bezier(.2,.8,.3,1)"
            }
        );

        setTimeout(() => {
            heart.remove();
        }, 1900);
    }
}


// ===============================
// BACKGROUND PARTICLES
// ===============================

function createParticles() {

    const container =
        document.getElementById("particles");

    const symbols = [
        "✦",
        "·",
        "♡",
        "✧",
        "✨"
    ];

    for (let i = 0; i < 45; i++) {

        const particle =
            document.createElement("div");

        particle.className =
            "particle";

        particle.innerHTML =
            symbols[
                Math.floor(
                    Math.random() * symbols.length
                )
            ];

        particle.style.left =
            Math.random() * 100 + "%";

        particle.style.fontSize =
            (8 + Math.random() * 15) + "px";

        particle.style.animationDuration =
            (7 + Math.random() * 10) + "s";

        particle.style.animationDelay =
            Math.random() * 10 + "s";

        container.appendChild(particle);
    }
}


// ===============================
// RESTART
// ===============================

function restart() {

    document.querySelectorAll(".screen")
        .forEach(screen => {
            screen.classList.remove("active");
        });

    document
        .getElementById("screen1")
        .classList.add("active");

    currentScreen = 1;

    updateProgress();
}


// ===============================
// INITIALIZE
// ===============================

createParticles();
updateProgress();